# Beauty Way Alaska — Build Your Beauty Box

Free static website for GitHub Pages.

## Publish
1. Create a public GitHub repository named `beauty-way-alaska`.
2. Upload `index.html` to the repository root.
3. Go to Settings → Pages → Deploy from a branch → `main` / `(root)` → Save.
4. Visit `https://YOUR-USERNAME.github.io/beauty-way-alaska/` after deployment.

## Ordering
Customers select products and quantities, see $20 / $40 / $60 shipping based on total item count, copy their order, and open Instagram @beautywayalaska to paste the order. Seller sends Square invoice; dispatch within 7 days of payment.

## Notes
Product prices were transcribed from the Square menu screenshots supplied October 22, 2026. The Boo Basket + Lip Kit combination is shown as $70 ($50 basket + $20 kit add-on). This is a separate bundle option; don't also add the individual basket and kit unless ordering extras. Product imagery is still placeholder. Inventory screenshot was used to identify variations, not live stock. Confirm availability before invoicing.
